# Spec basis (the oracle) — fetched 2026-10-11

## 1. TOML ABNF (main branch = TOML v1.1.0 edition grammar)
Source: https://raw.githubusercontent.com/toml-lang/toml/main/toml.abnf
Verbatim excerpts (full file archived in this directory as `toml.abnf`):

> ;; Although a TOML document must be valid UTF-8, this grammar refers to the
> ;; Unicode Code Points you get after you decode the UTF-8 input.

> non-ascii = %x80-D7FF / %xE000-10FFFF

(i.e. the ABNF's "non-ascii" terminal excludes the surrogate block U+D800-U+DFFF.)

> basic-unescaped = wschar / %x21 / %x23-5B / %x5D-7E / non-ascii
> escaped = escape escape-seq-char
> escape = %x5C                   ; \
> escape-seq-char =  %x22         ; "    quotation mark  U+0022
> escape-seq-char =/ %x5C         ; \    reverse solidus U+005C
> escape-seq-char =/ %x62         ; b    backspace       U+0008
> escape-seq-char =/ %x65         ; e    escape          U+001B
> escape-seq-char =/ %x66         ; f    form feed       U+000C
> escape-seq-char =/ %x6E         ; n    line feed       U+000A
> escape-seq-char =/ %x72         ; r    carriage return U+000D
> escape-seq-char =/ %x78 2HEXDIG ; xHH                  U+00HH
> escape-seq-char =/ %x75 4HEXDIG ; uHHHH                U+HHHH
> escape-seq-char =/ %x55 8HEXDIG ; UHHHHHHHH            U+HHHHHHHH

Note `%x78 2HEXDIG ; xHH U+00HH`: the escape's value is the code point U+00HH
(a Unicode scalar value to be UTF-8 encoded in the decoded string), exactly
2 hex digits.

## 2. TOML v1.0.0 (https://toml.io/en/v1.0.0)
Verbatim excerpts:

> A TOML file must be a valid UTF-8 encoded Unicode document.

> There are four ways to express strings: basic, multi-line basic, literal,
> and multi-line literal. All strings must contain only valid UTF-8 characters.

> \uXXXX     - unicode         (U+XXXX)
> \UXXXXXXXX - unicode         (U+XXXXXXXX)
> Any Unicode character may be escaped with the \uXXXX or \UXXXXXXXX forms.
> The escape codes must be valid Unicode scalar values.

> All other escape sequences not listed above are reserved; if they are used,
> TOML should produce an error.

(v1.0.0 has NO \xHH and NO \e escape; both are v1.1.0 additions.)

## 3. TOML v1.1.0 (https://toml.io/en/v1.1.0, published 12/18/2025)
Verbatim excerpts:

> A TOML file must be a valid UTF-8 encoded Unicode document.
> Specifically this means that a file as a whole must form a
> well-formed code-unit sequence. Otherwise, it must be rejected (preferably)
> or have ill-formed byte sequences replaced with U+FFFD, as per the Unicode
> specification.

> There are four ways to express strings: basic, multi-line basic, literal,
> and multi-line literal. All strings must contain only Unicode characters.

> \xHH       - unicode         (U+00HH)
> \uHHHH     - unicode         (U+HHHH)
> \UHHHHHHHH - unicode         (U+HHHHHHHH)
> Any Unicode character may be escaped with the \xHH, \uHHHH, or \UHHHHHHHH
> forms. The escape codes must be Unicode scalar values.

> Keep in mind that all TOML strings are sequences of Unicode characters, not
> byte sequences. For binary data, avoid using these escape codes. Instead,
> external binary-to-text encoding strategies, like hexadecimal sequences or
> Base64, are recommended for converting between bytes and strings.

Interpretation for the escape-interaction check (version-scoped): under
v1.1.0, `\x80` denotes the code point U+0080. A conforming decoder must put
the UTF-8 encoding of U+0080 — bytes C2 80 — into the string value, because
"TOML strings are sequences of Unicode characters, not byte sequences."
Inserting the single raw byte 0x80 instead produces a lone continuation byte,
which is not well-formed UTF-8 and denotes no Unicode character.
